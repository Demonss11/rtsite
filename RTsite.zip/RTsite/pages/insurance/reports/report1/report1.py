#python
import webbrowser
webbrowser.open_new_tab(r'D:\LinuxFolder\Site_MyNewSkill.ru\pages\insurance\reports\report1\index.html')