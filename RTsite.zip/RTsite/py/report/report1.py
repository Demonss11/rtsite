print("Content-type: text/html")
print()
print("<h1>Hello world!</h1>")