from http.server import HTTPServer, CGIHTTPRequestHandler
import datetime

class TestServerHandler(CGIHTTPRequestHandler):

    class Counter:
        def __init__(self):
            self.counter = 0
            self.timer = datetime.datetime.now()

        def check_count(self, now):
            delta_time = now - self.timer
            if self.counter == 0 or delta_time.seconds > 100000:
                self.counter = 0
                self.timer = now
                return True
            return False

        def add_c(self, now):
            self.counter += 1
            self.timer = now

    counter = Counter()

    @classmethod
    def check_count(cls):
        return cls.counter.check_count(datetime.datetime.now())

    @classmethod
    def add_c(cls):
        cls.counter.add_c(datetime.datetime.now())

    @classmethod
    def show(cls):
        return cls.counter.timer

    def do_POST(self):
        # if self.path == '/':
        #     self.path = "./index.html"
        if self.check_count():
            content_length = int(self.headers['Content-Length'])
            data_input = bytes.decode(self.rfile.read(content_length))
            print(data_input)
            self.add_c()
            print(self.show())
        else:
            print(self.show())


test_server = HTTPServer(('localhost', 8080), TestServerHandler)
test_server.serve_forever()
